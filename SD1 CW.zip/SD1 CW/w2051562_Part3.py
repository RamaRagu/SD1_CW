# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion. 
# Any code taken from other sources is referenced within my code soluƟon.
# Student ID: 20230137
# Date: 13/12/2023

from graphics import *
import sys

# Declare global variables
id_list = []
pass_credits = 0
defer_credits = 0
fail_credits = 0
progress_count = 0
trailer_count = 0
retriever_count = 0
excluded_count = 0
total_count = 0


progression = open("Progression_display.txt","w")                #open the text file in write mode    


# Function for ID check
def id_check():
    #checks whether the UOW ID is in a correct format
    stu_id = input("Enter the IIT UOW ID: ")
    if stu_id.lower()[0] == "w" and len(stu_id) == 8:
        if stu_id in id_list:
            print("This ID already exists in the process.")
            return id_check()
        else:
            id_list.append(stu_id)
    else:
        print("Invalid ID.")
        return id_check()
    
#Function for Staff ID check
# Check to prevent students from attempting to pose as staff illegally
def staff_id_check():
    staff_id=input("Enter your staff ID")
    if staff_id.lower()[0]=="s" and len(staff_id)==8:
        pass
    else:
        print("Invalid Staff ID")
        return staff_id_check()

# Function for range validation
def validation(num):
    while True:
        try:
            credit = int(input(num))
            if credit not in [0, 20, 40, 60, 80, 100, 120]:                               #checks whether the input is in a range
                print("Out of range")
            else:
                return credit
        except ValueError:
            print("Integer required")

# Function for module checking
def module_checker(total, pass_credits, defer_credits, fail_credits):
    global progress_count, trailer_count, retriever_count, excluded_count, total_count
    if total != 120:
        print("Total incorrect")
    else:
        if pass_credits == 120:
            print("Progress",end="  ")                                         #total no of progress
            progress_count += 1
            progression.write("Progress – " + str(pass_credits) + ", " + str(defer_credits) + ", " + str(fail_credits) +"\n")

        elif pass_credits == 100:
            print("Progress (module trailer)",end="  ")            #total no of trailer
            trailer_count += 1
            progression.write("Progress (module trailer) –  " + str(pass_credits) + ", " + str(defer_credits) + ", " + str(fail_credits) + "\n")

        elif fail_credits >= 80:
            print("Exclude",end=" ")                                          #total no of Excluded
            excluded_count += 1
            progression.write("Exclude –  " + str(pass_credits) + ", " + str(defer_credits) + ", " + str(fail_credits) + "\n")

        else:
            print("Module retriever",end="  ")                           #total no of retriever
            retriever_count += 1
            progression.write("Module retriever – " + str(pass_credits) + ", " + str(defer_credits) + ", " + str(fail_credits) +"\n")
        total_count = progress_count + trailer_count + retriever_count + excluded_count

# Function for histogram
def histogram():
    try:
        win = GraphWin(" Histogram", 600, 500)
        win.setBackground("white")
                       
        heading = Text(Point(180,35 ), "Histogram Results")
        heading.setStyle("bold")
        heading.setSize(22)
        heading.draw(win)

        v_line = Line(Point(30,400), Point(570,400))
        v_line.draw(win)
                     
        unit_bar_height = int(30)
        bar_height = int(400)
        bar_space = int(20)
        bar_width = int(110)

        progression_dic={"Progress":progress_count,"Trailer":trailer_count,"Retriever":retriever_count,"Excluded":excluded_count}
        color_list=["lawngreen","lime","olivedrab","Pink"]
        for index, key in enumerate(progression_dic):
            #lable creation for each progression types
            progression_lable = Text(Point(100 + (bar_width * index) + (bar_space * index), bar_height + 20), key)
            progression_lable.setStyle("bold")
            progression_lable.setTextColor("Grey")
            progression_lable.setSize(15)
            progression_lable.draw(win)
            #bar creation for each progression types
            p_bar = Rectangle(Point(50 +(bar_width*index ) + (bar_space * index),bar_height),Point(50+bar_width +(bar_width*index ) +(bar_space * index),(bar_height-(unit_bar_height*progression_dic[key]))))
            p_bar.setFill(color_list[index])
            p_bar.draw(win)
            #counting lable creation for each progression types
            count_lable = Text(Point(100 + (bar_width * index) + (bar_space * index), bar_height - 10 - (unit_bar_height * progression_dic[key])), progression_dic[key])
            count_lable.setTextColor("Grey")
            count_lable.setStyle("bold")
            count_lable.draw(win)
            #printing the total no of counts the process happened
        total_lable = Text(Point(70,465), total_count)
        total_lable.setStyle("bold")
        total_lable.setTextColor("Grey")
        total_lable.setSize(17)
        total_lable.draw(win)
                       
        total_lable = Text(Point(200,465), " outcomes in total.")
        total_lable.setStyle("bold")
        total_lable.setTextColor("Grey")
        total_lable.setSize(17)
        total_lable.draw(win)
                       
                       
        win.getMouse() 
        win.close()

    except GraphicsError:
        print()

#Function for Student /Staff selection
def occupation():
    position = input("Staff or Student: ").lower()
    return position

#Main calling Program
position = occupation()
while position not in ["staff", "student"]:
    print("Invalid position")
    position = occupation()

  
if position == "staff":
        staff_id_check()
        
while True:
    id_check()
    pass_credits = validation("Please enter your credits at pass: ")
    defer_credits = validation("Please enter your credits at defer: ")
    fail_credits = validation("Please enter your credits at fail: ")
    total = pass_credits + defer_credits + fail_credits  # Total
    module_checker(total, pass_credits, defer_credits, fail_credits)

    if position == "student":
        print(pass_credits, defer_credits, fail_credits)
        break  # For students, input only once

    print("\n")

    def confirmation():
        confirm = input("Would you like to enter another set of data? ('y' for yes or 'q' for quit)").lower()
        if confirm == "q":
            global progression
            print("Part 3: ")
            progression = open("Progression_display.txt", "r")  # open the text file in read mode
            print(progression.read())  # print the text file content
            progression.close()  # close the text file

            histogram()  # Calling histogram when quitting
            sys.exit()  # Exit the program
        elif confirm not in ["y", "q"]:
            print("Invalid input")
            return confirmation()
    confirm = confirmation()

